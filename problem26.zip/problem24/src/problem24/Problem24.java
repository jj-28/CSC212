/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problem24;

import java.util.*;

/**
 *
 * @author mohammad
 */
public class Problem24 {

    public static void insertionSort(int[] x) {
        for (int i = 0; i < x.length - 1; i++) {
            int smallest = i;
            for (int j = i + 1; j < x.length; j++) {
                if (x[smallest] > x[j]) {
                    smallest = j;
                }
            }
            int temp = x[i];
            x[i] = x[smallest];
            x[smallest] = temp;

        }

    }

    public static void out(int[] x) {
        for (int i = 0; i < x.length; i++) {
            System.out.println(x[i]);
        }
    }

    public static void main(String[] args) {
        int[] x = new int[10];
        Random r = new Random();
        for (int i = 0; i < x.length; i++) {
            x[i] = r.nextInt(50000);
        }
        System.out.println("List before sort");
        out(x);
        insertionSort(x);
        System.out.println("List before sort");
        out(x);
    }

}
