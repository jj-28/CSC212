/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jeffr
 */
import java.util.*;
import java.io.*;

public class Dictionary {

    static HashMap<String, dictionaryEntry> x = new HashMap();

    public static void load(Scanner sc) {
        while (sc.hasNext()) {
            dictionaryEntry d = new dictionaryEntry(sc.next(), sc.nextLine());
            x.put(d.getWord(),d);

        }
    }

    public boolean Add(String word, dictionaryEntry d) {
        if (x.containsKey(d.word)) {
            if (x.containsValue(d)) {
            }
            return false;
        } else {
            x.put(d.word, d);
            return true;
        }

    }

    public boolean Delete(String word) {
        if (x.containsKey(word)) {
            x.remove(word);
            return true;
        } else {
            return false;
        }

    }

    public dictionaryEntry find(String word) {
        if (x.containsKey(word)) {
            return x.get(word);
        } else {
            return null;
        }
    }

    public void browse(String word) {
        Collection<dictionaryEntry> words = x.values();
        ArrayList<dictionaryEntry>s = new ArrayList<dictionaryEntry>(words);  
        //ArrayList<dictionaryEntry> de= new ArrayList<dictionaryEntry>();
        for(int i = 0; i < s.size(); i++) {
          if(s.get(i).toString().startsWith(word)){
          System.out.println(s.get(i));
          }
        }
} 
}
