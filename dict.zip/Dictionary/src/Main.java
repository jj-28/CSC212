/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jeffr
 */
import java.util.*;
import  java.io.*;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
Scanner reader = new Scanner(new FileInputStream("C:/Users/jeffr/Documents/CSC 212/Dictionary/src/dict.txt"));        
Dictionary r = new Dictionary();
r.load(reader);
//System.out.println(r.find("fang"));
r.browse("a");


//r.Add("testicles","df");

    
    
    
    
    
    }
    }
