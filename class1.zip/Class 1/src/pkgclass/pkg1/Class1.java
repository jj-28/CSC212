/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgclass.pkg1;

/**
 *
 * @author jeffr
 */
public class Class1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int x = 845;
       System.out.println("hello");
       System.out.println("I am Jeffrey aka Extendo the God " + x + ", dont test me");
        // TODO code application logic here
    }
    
}
