/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problem23;
import java.util.HashMap;
/**
 *
 * @author mohammad
 */
public class Problem23 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HashMap x = new HashMap();
        
        x.put("hello", "a greeting");
        x.put("hi", "another greeting");
        
        System.out.println(x);
     System.out.println(x.get("no"));
        //How do I displau each word and definition stored in x; one at a time?
        
        
    }
    
}
