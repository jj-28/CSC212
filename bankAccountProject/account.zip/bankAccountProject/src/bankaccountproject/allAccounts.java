/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bankaccountproject;

import java.util.Scanner;

/**
 *
 * * Name:
 * create and maintain all accounts
 * 
 */
public class allAccounts {
   // need an static array that holds all accounts. Also need a static integer that tracks
   // how many accounts there are in the array
    
    
    
    
    //this method gets the scanner object for the data file that holds all 
    //account information.  It need to then read each line holding data for an account
    // (name, pin, etc.) and then store that account in the array, keeping track of how 
    //many accounts there are.
    public static void load (Scanner scan) {
        
    }
    
    //locate an return the account with the name matching the paramter. If no account
    //is found with this name, the method returns null. This method temporarily returns null.
    public static Account locate (String name) {
        return null;
    }
    
    
}
