package bankaccountproject;

import java.io.FileInputStream;
import java.util.Scanner;

/**
 *
 * @author mohammad
 * This application will test allAccounts and Account classes.  We create 
 * accounts and make sure they have the functionality they need. We'll also 
 * create an allAccounts object that will let us make sure we can maintain and 
 * store a set of bankAccounts.
 * 
 */
public class BankAccountProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        Scanner reader = new Scanner(new FileInputStream("accounts.txt"));
        
        allAccounts.load(reader);  //store account in allAccounts
        
        //Write a look that outputs all bank account data stores
        
        Account a = allAccounts.locate("jones");
        
        if (a == null) {
            System.out.println ("Jones does not have an account with us");
        }
        else {
            //output Jones's account information
        }  
        
    }
    
}
