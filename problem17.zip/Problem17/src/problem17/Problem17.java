/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problem17;

/**
 *
 * @author mohammad
 */
public class Problem17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] x = new int[10];

        int[][] twoD = new int[10][10];

        for (int i = 0; i < 10; i++) {
            x[i] = 0;
        }

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                twoD[i][j] = 0;
            }
        }

        for (int i = 0; i < 10; i++) {
            if (i % 2 == 0) {
                x[i] = 1;
            } else {
                x[i] = 0;
            }

        }
        for (int i = 0; i < 10; i++) {
            System.out.println(x[i]);
        }

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (i % 2 == 0) {
                    twoD[i][j] = 1;
                } else {
                    twoD[i][j] = 0;
                }
            }
        }
        
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print (twoD[i] [j] + "\t");
            }
            System.out.println();
        }
        
        
        
    }

}
