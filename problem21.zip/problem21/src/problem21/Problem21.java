/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problem21;

/**
 *
 * @author mohammad
 */
public class Problem21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        stack l1 = new stack();
        stack l2 = new stack();
        
        
        l1.push("hello");
        l1.push("goodbye");
        
        l2.push(l1.peek());
        l1.pop();
        
       System.out.println(l1.peek());
       System.out.println(l2.peek());
        
    }
    
}
